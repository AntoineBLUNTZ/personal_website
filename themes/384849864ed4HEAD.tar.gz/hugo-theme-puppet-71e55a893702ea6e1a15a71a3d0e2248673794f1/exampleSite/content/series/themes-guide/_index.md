+++
title = "Themes Guide"
description = "a series of posts about configuring and using Hugo themes"
header_img = "img/home-bg.jpg"
short = true
+++